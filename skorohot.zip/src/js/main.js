/*
 * Custom
 */

document.addEventListener("DOMContentLoaded", function(event) {
  //= ../../node_modules/jquery/dist/jquery.js

  //= ../../node_modules/slick-carousel/slick/slick.js

  //= partials/top-menu.js

  //= partials/smooth-scrolling.js

  //= partials/top-slider.js

  //= partials/pizza-slider.js

  //= partials/japan-food-slider.js

  //= partials/specials-slider.js

  //= partials/reviews-slider.js

  //= partials/social-media-slider.js

  //= partials/product-slider.js

  //= partials/with-this-slider.js

  //= partials/drinks-slider.js

  //= partials/deserts-slider.js

  //= partials/sushi-slider.js

  //= partials/action-slider.js

  //= partials/method.js

  //= partials/social-media-vk.js

  //= partials/social-media-ok.js

  //= partials/map.js

  //= partials/phone-mask.js
});
