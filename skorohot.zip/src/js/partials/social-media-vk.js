$(document).ready(function(){
  VK.Widgets.Group("vk_groups", {mode: 3, width: "550", height: "220"}, 148426161);
});
