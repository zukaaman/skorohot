$(document).ready(function(){
  $('.actions__middle').slick({
    slidesToShow: 1,
    arrows: false,
    dots: true,
    autoplay: true,
    autoplaySpeed: 6000,
    speed: 500,
    fade: true
  });
});
