$(document).ready(function(){
  $('.deserts-slider').slick({
    slidesToShow: 4,
    prevArrow: '<button class="deserts-slider__button-left" type="button"><span class="visually-hidden">left</span></button>',
    nextArrow: '<button class="deserts-slider__button-right" type="button"><span class="visually-hidden">right</span></button>'
  });
});
